# coding: UTF-8
from tkinter import *

from config import *
import data
import model

root = Tk()
root.geometry("500x400")
root.configure(bg="wheat")
root.resizable(width=True, height=True)
root.title("写诗")


def head():
    parser = argparse.ArgumentParser(description="Chinese_poem_generator.")
    parser.add_argument("-m", "--mode", help="select mode by 'train' or 'test' or 'head'",
                        choices=["train", "test", "head"], default="head")
    trainData = data.POEMS(trainPoems)
    MCPangHu = model.MODEL(trainData)
    characters = text3.get("1.0", "end-1c")
    poems = MCPangHu.testHead(characters)
    text1.insert("end", poems)


text1 = Text(root, font=("华文行楷", 20, "bold"))  # 字符数、行数
text1.place(x=50, y=110, height=200, width=380)

text2 = Text(root, font=("华文行楷", 20, "bold"))  # 字符数、行数
text2.place(x=50, y=60, height=40, width=170)
text2.insert("1.0", "请输入主题:")

text3 = Text(root, font=("华文行楷", 20, "bold"))  # 字符数、行数
text3.place(x=230, y=60, height=40, width=200)

mode1 = Button(root, text="藏头诗", font=("华文行楷", 20, "bold"), bg="steelblue", command=head)
mode1.place(x=175, y=5, height=40, width=150)

def clear():
    text1.delete("1.0", "end")

mode2 = Button(root, text="清空", bg="steelblue", command=clear)
mode2.place(x=175, y=320, height=30, width=100)

root.mainloop()
