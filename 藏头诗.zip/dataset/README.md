﻿本文件夹下数据来源于[https://github.com/chinese-poetry/chinese-poetry](https://github.com/chinese-poetry/chinese-poetry)

- poetryTang: 唐诗5w首
- poetrySong: 宋诗26w首，默认训练数据
- songci: 宋词，2w首
- shijing: 诗经，比较少，训练效果不太好